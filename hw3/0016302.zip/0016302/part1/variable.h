#ifndef VARABLE_H
#define VARABLE_H

#include "constant.h"
#include "type.h"

extern Request req[MAX_REQUEST];

#endif
