#ifndef CONSTANT_H
#define CONSTANT_H

#define DEBUG           0

#define MAX_REQUEST     5
#define MAX_PATH_LENGTH 512
#define BUFSIZE         10240

#define FILES_PATH_DIR  "/root/network-programming/hw3/code/cgi/files/"

#endif
